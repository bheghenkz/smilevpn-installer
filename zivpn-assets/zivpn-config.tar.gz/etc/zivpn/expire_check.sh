#!/bin/bash
DB_FILE="/etc/zivpn/users.db"
CONFIG_FILE="/etc/zivpn/config.json"
TMP_DB_FILE="${DB_FILE}.tmp"
LOCK_FILE="${DB_FILE}.lock"
CURRENT_DATE=$(date +%s)
SERVICE_RESTART_NEEDED=false
LOCK_FD=""

acquire_lock() {
    exec {lock_fd}>"$LOCK_FILE" || return 1
    if ! flock -x "$lock_fd"; then
        eval "exec ${lock_fd}>&-"
        return 1
    fi
    LOCK_FD="$lock_fd"
}

release_lock() {
    [ -n "$LOCK_FD" ] || return 0
    flock -u "$LOCK_FD" 2>/dev/null || true
    eval "exec ${LOCK_FD}>&-"
    LOCK_FD=""
}

cleanup() {
    [ -n "$TMP_DB_FILE" ] && rm -f "$TMP_DB_FILE"
    release_lock
}

trap cleanup EXIT

if [ ! -f "$DB_FILE" ]; then exit 0; fi
if ! acquire_lock; then exit 1; fi
> "$TMP_DB_FILE"

while IFS=':' read -r password expiry_date; do
    if [[ -z "$password" ]]; then continue; fi

    if ! [[ "$expiry_date" =~ ^[0-9]+$ ]]; then
        echo "${password}:${expiry_date}" >> "$TMP_DB_FILE"
        continue
    fi

    if [ "$expiry_date" -le "$CURRENT_DATE" ]; then
        echo "User '${password}' has expired. Deleting permanently."
        jq --arg pass "$password" 'del(.auth.config[] | select(. == $pass))' "$CONFIG_FILE" > "${CONFIG_FILE}.tmp" && mv "${CONFIG_FILE}.tmp" "$CONFIG_FILE"
        SERVICE_RESTART_NEEDED=true
    else
        echo "${password}:${expiry_date}" >> "$TMP_DB_FILE"
    fi
done < "$DB_FILE"

mv "$TMP_DB_FILE" "$DB_FILE"
TMP_DB_FILE=""

if [ "$SERVICE_RESTART_NEEDED" = true ]; then
        echo "User(s) removed, but skipping service restart to avoid disconnecting active users."
        echo "Use menu 15 or 16 for manual cleanup with restart when needed."
    fi
exit 0
