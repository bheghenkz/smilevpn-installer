const express = require('express');
const { execFile } = require('child_process');
const fs = require('fs');
const app = express();
const PORT = 5888;
const AUTH_KEY_PATH = '/etc/zivpn/api_auth.key';
const ZIVPN_MANAGER_SCRIPT = '/usr/local/bin/zivpn-manager';

const authenticate = (req, res, next) => {
    const providedAuthKey = req.query.auth;
    if (!providedAuthKey) return res.status(401).json({ status: 'error', message: 'Authentication key is required.' });

    fs.readFile(AUTH_KEY_PATH, 'utf8', (err, storedKey) => {
        if (err) return res.status(500).json({ status: 'error', message: 'Could not read authentication key.' });
        if (providedAuthKey.trim() !== storedKey.trim()) return res.status(403).json({ status: 'error', message: 'Invalid authentication key.' });
        next();
    });
};
app.use(authenticate);

const executeZivpnManager = (command, args, res) => {
    execFile('sudo', [ZIVPN_MANAGER_SCRIPT, command, ...args], (error, stdout, stderr) => {
        if (error) {
            const errorMessage = stderr.includes('Error:') ? stderr : 'An internal server error occurred.';
            return res.status(500).json({ status: 'error', message: errorMessage.trim() });
        }
        if (stdout.toLowerCase().includes('success')) {
            res.json({ status: 'success', message: stdout.trim() });
        } else {
            res.status(400).json({ status: 'error', message: stdout.trim() });
        }
    });
};

app.all('/create/zivpn', (req, res) => {
    const { password, exp } = req.query;
    if (!password || !exp) return res.status(400).json({ status: 'error', message: 'Parameters password and exp are required.' });
    executeZivpnManager('create_account', [password, exp], res);
});
app.all('/delete/zivpn', (req, res) => {
    const { password } = req.query;
    if (!password) return res.status(400).json({ status: 'error', message: 'Parameter password is required.' });
    executeZivpnManager('delete_account', [password], res);
});
app.all('/renew/zivpn', (req, res) => {
    const { password, exp } = req.query;
    if (!password || !exp) return res.status(400).json({ status: 'error', message: 'Parameters password and exp are required.' });
    executeZivpnManager('renew_account', [password, exp], res);
});
app.all('/trial/zivpn', (req, res) => {
    const { exp } = req.query;
    if (!exp) return res.status(400).json({ status: 'error', message: 'Parameter exp is required.' });
    executeZivpnManager('trial_account', [exp], res);
});

app.listen(PORT, () => console.log('ZIVPN API server running on port ' + PORT));
